package com.sac.speech.ui.animators;

public interface BarParamsAnimator {
    void start();
    void stop();
    void animate();
}
