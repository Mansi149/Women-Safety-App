package com.womensafety.shajt3ch;

public class PhoneNumber {
    public  static String phoneNumber = "01521313051";

}
